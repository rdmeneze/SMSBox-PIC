extern void boot_loader(void);
